package com.chromatictuner.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.Composable

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TunerScreen() }
    }
}

@Composable
fun TunerScreen() {
    Surface {
        Text("Chromatic Tuner\n\nОжидание сигнала 🎸")
    }
}
